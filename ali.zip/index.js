const express = require("express")
const app = express()
const bodyParser = require("body-parser")
require('dotenv').config()

const mongoose=require("mongoose")

app.use(bodyParser.json({ limit: '700mb' }));
app.use(bodyParser.urlencoded({ limit: '700mb', extended: true }));



app.use("/files", express.static('files'))


const regist=require("./routs/registion")
app.use("/regist",regist)


const upload=require("./routs/upload")
app.use("/upload",upload)


mongoose.connect(process.env.DB,()=>{
    console.log("connected to db");
})
app.listen(2323, () => { console.log("server is runing on port 2323"); })