const base_url = "http://localhost:2323"

module.exports = { base_url }